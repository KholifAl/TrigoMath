gdjs.PerpusCode = {};
gdjs.PerpusCode.localVariables = [];
gdjs.PerpusCode.GDDialogBoxdObjects1= [];
gdjs.PerpusCode.GDDialogBoxdObjects2= [];
gdjs.PerpusCode.GDDialogBoxdObjects3= [];
gdjs.PerpusCode.GDPlayerObjects1= [];
gdjs.PerpusCode.GDPlayerObjects2= [];
gdjs.PerpusCode.GDPlayerObjects3= [];
gdjs.PerpusCode.GDNPCObjects1= [];
gdjs.PerpusCode.GDNPCObjects2= [];
gdjs.PerpusCode.GDNPCObjects3= [];
gdjs.PerpusCode.GDTree1Objects1= [];
gdjs.PerpusCode.GDTree1Objects2= [];
gdjs.PerpusCode.GDTree1Objects3= [];
gdjs.PerpusCode.GDTree2Objects1= [];
gdjs.PerpusCode.GDTree2Objects2= [];
gdjs.PerpusCode.GDTree2Objects3= [];
gdjs.PerpusCode.GDBush1Objects1= [];
gdjs.PerpusCode.GDBush1Objects2= [];
gdjs.PerpusCode.GDBush1Objects3= [];
gdjs.PerpusCode.GDHouse1Objects1= [];
gdjs.PerpusCode.GDHouse1Objects2= [];
gdjs.PerpusCode.GDHouse1Objects3= [];
gdjs.PerpusCode.GDHouse2Objects1= [];
gdjs.PerpusCode.GDHouse2Objects2= [];
gdjs.PerpusCode.GDHouse2Objects3= [];
gdjs.PerpusCode.GDEObjects1= [];
gdjs.PerpusCode.GDEObjects2= [];
gdjs.PerpusCode.GDEObjects3= [];
gdjs.PerpusCode.GDE2Objects1= [];
gdjs.PerpusCode.GDE2Objects2= [];
gdjs.PerpusCode.GDE2Objects3= [];
gdjs.PerpusCode.GDShadedDarkJoystickObjects1= [];
gdjs.PerpusCode.GDShadedDarkJoystickObjects2= [];
gdjs.PerpusCode.GDShadedDarkJoystickObjects3= [];
gdjs.PerpusCode.GDTargetRoundButtonObjects1= [];
gdjs.PerpusCode.GDTargetRoundButtonObjects2= [];
gdjs.PerpusCode.GDTargetRoundButtonObjects3= [];
gdjs.PerpusCode.GDTilemap_9595GroundObjects1= [];
gdjs.PerpusCode.GDTilemap_9595GroundObjects2= [];
gdjs.PerpusCode.GDTilemap_9595GroundObjects3= [];
gdjs.PerpusCode.GDTilemap_9595WaterObjects1= [];
gdjs.PerpusCode.GDTilemap_9595WaterObjects2= [];
gdjs.PerpusCode.GDTilemap_9595WaterObjects3= [];
gdjs.PerpusCode.GDCameraTargetObjects1= [];
gdjs.PerpusCode.GDCameraTargetObjects2= [];
gdjs.PerpusCode.GDCameraTargetObjects3= [];
gdjs.PerpusCode.GDTile_9595dalamObjects1= [];
gdjs.PerpusCode.GDTile_9595dalamObjects2= [];
gdjs.PerpusCode.GDTile_9595dalamObjects3= [];
gdjs.PerpusCode.GDNewSpriteObjects1= [];
gdjs.PerpusCode.GDNewSpriteObjects2= [];
gdjs.PerpusCode.GDNewSpriteObjects3= [];
gdjs.PerpusCode.GDdddObjects1= [];
gdjs.PerpusCode.GDdddObjects2= [];
gdjs.PerpusCode.GDdddObjects3= [];
gdjs.PerpusCode.GDPortalObjects1= [];
gdjs.PerpusCode.GDPortalObjects2= [];
gdjs.PerpusCode.GDPortalObjects3= [];
gdjs.PerpusCode.GDobjekObjects1= [];
gdjs.PerpusCode.GDobjekObjects2= [];
gdjs.PerpusCode.GDobjekObjects3= [];
gdjs.PerpusCode.GDNewTileMapObjects1= [];
gdjs.PerpusCode.GDNewTileMapObjects2= [];
gdjs.PerpusCode.GDNewTileMapObjects3= [];
gdjs.PerpusCode.GDmejaObjects1= [];
gdjs.PerpusCode.GDmejaObjects2= [];
gdjs.PerpusCode.GDmejaObjects3= [];
gdjs.PerpusCode.GDdepanObjects1= [];
gdjs.PerpusCode.GDdepanObjects2= [];
gdjs.PerpusCode.GDdepanObjects3= [];
gdjs.PerpusCode.GDmakanObjects1= [];
gdjs.PerpusCode.GDmakanObjects2= [];
gdjs.PerpusCode.GDmakanObjects3= [];
gdjs.PerpusCode.GDddd2Objects1= [];
gdjs.PerpusCode.GDddd2Objects2= [];
gdjs.PerpusCode.GDddd2Objects3= [];
gdjs.PerpusCode.GD_95951Objects1= [];
gdjs.PerpusCode.GD_95951Objects2= [];
gdjs.PerpusCode.GD_95951Objects3= [];
gdjs.PerpusCode.GDNewSprite2Objects1= [];
gdjs.PerpusCode.GDNewSprite2Objects2= [];
gdjs.PerpusCode.GDNewSprite2Objects3= [];
gdjs.PerpusCode.GDDialogueObjects1= [];
gdjs.PerpusCode.GDDialogueObjects2= [];
gdjs.PerpusCode.GDDialogueObjects3= [];
gdjs.PerpusCode.GDDiaBoxObjects1= [];
gdjs.PerpusCode.GDDiaBoxObjects2= [];
gdjs.PerpusCode.GDDiaBoxObjects3= [];
gdjs.PerpusCode.GDDiaTextObjects1= [];
gdjs.PerpusCode.GDDiaTextObjects2= [];
gdjs.PerpusCode.GDDiaTextObjects3= [];
gdjs.PerpusCode.GDIndicatorObjects1= [];
gdjs.PerpusCode.GDIndicatorObjects2= [];
gdjs.PerpusCode.GDIndicatorObjects3= [];
gdjs.PerpusCode.GDContinueIconObjects1= [];
gdjs.PerpusCode.GDContinueIconObjects2= [];
gdjs.PerpusCode.GDContinueIconObjects3= [];
gdjs.PerpusCode.GDDialogue2Objects1= [];
gdjs.PerpusCode.GDDialogue2Objects2= [];
gdjs.PerpusCode.GDDialogue2Objects3= [];
gdjs.PerpusCode.GDTransitionObjects1= [];
gdjs.PerpusCode.GDTransitionObjects2= [];
gdjs.PerpusCode.GDTransitionObjects3= [];


gdjs.PerpusCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20615028);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(2), "Text1");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(2), "Text ke2");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(2), "Pergi ke pintu nomor 1");
}}

}


};gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.PerpusCode.GDPlayerObjects1});
gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.PerpusCode.GDNewSprite2Objects1});
gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDTree1Objects1ObjectsGDgdjs_9546PerpusCode_9546GDBush1Objects1ObjectsGDgdjs_9546PerpusCode_9546GDTree2Objects1ObjectsGDgdjs_9546PerpusCode_9546GDHouse1Objects1ObjectsGDgdjs_9546PerpusCode_9546GDHouse2Objects1ObjectsGDgdjs_9546PerpusCode_9546GDNPCObjects1ObjectsGDgdjs_9546PerpusCode_9546GDTilemap_95959595GroundObjects1ObjectsGDgdjs_9546PerpusCode_9546GDTilemap_95959595WaterObjects1ObjectsGDgdjs_9546PerpusCode_9546GDNewSpriteObjects1ObjectsGDgdjs_9546PerpusCode_9546GDobjekObjects1ObjectsGDgdjs_9546PerpusCode_9546GDdepanObjects1ObjectsGDgdjs_9546PerpusCode_9546GDmejaObjects1ObjectsGDgdjs_9546PerpusCode_9546GDddd2Objects1Objects = Hashtable.newFrom({"Tree1": gdjs.PerpusCode.GDTree1Objects1, "Bush1": gdjs.PerpusCode.GDBush1Objects1, "Tree2": gdjs.PerpusCode.GDTree2Objects1, "House1": gdjs.PerpusCode.GDHouse1Objects1, "House2": gdjs.PerpusCode.GDHouse2Objects1, "NPC": gdjs.PerpusCode.GDNPCObjects1, "Tilemap_Ground": gdjs.PerpusCode.GDTilemap_9595GroundObjects1, "Tilemap_Water": gdjs.PerpusCode.GDTilemap_9595WaterObjects1, "NewSprite": gdjs.PerpusCode.GDNewSpriteObjects1, "objek": gdjs.PerpusCode.GDobjekObjects1, "depan": gdjs.PerpusCode.GDdepanObjects1, "meja": gdjs.PerpusCode.GDmejaObjects1, "ddd2": gdjs.PerpusCode.GDddd2Objects1});
gdjs.PerpusCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
/* Reuse gdjs.PerpusCode.GDShadedDarkJoystickObjects2 */
gdjs.copyArray(runtimeScene.getObjects("TargetRoundButton"), gdjs.PerpusCode.GDTargetRoundButtonObjects2);
{for(var i = 0, len = gdjs.PerpusCode.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDShadedDarkJoystickObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.PerpusCode.GDTargetRoundButtonObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDTargetRoundButtonObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDDialogBoxdObjects1ObjectsGDgdjs_9546PerpusCode_9546GDTargetRoundButtonObjects1Objects = Hashtable.newFrom({"DialogBoxd": gdjs.PerpusCode.GDDialogBoxdObjects1, "TargetRoundButton": gdjs.PerpusCode.GDTargetRoundButtonObjects1});
gdjs.PerpusCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.PerpusCode.GDShadedDarkJoystickObjects2);
{for(var i = 0, len = gdjs.PerpusCode.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDShadedDarkJoystickObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.PerpusCode.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDShadedDarkJoystickObjects2[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PerpusCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DialogBoxd"), gdjs.PerpusCode.GDDialogBoxdObjects1);
gdjs.copyArray(runtimeScene.getObjects("TargetRoundButton"), gdjs.PerpusCode.GDTargetRoundButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.PerpusCode.GDDialogBoxdObjects1.length;i<l;++i) {
    if ( gdjs.PerpusCode.GDDialogBoxdObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.PerpusCode.GDDialogBoxdObjects1[k] = gdjs.PerpusCode.GDDialogBoxdObjects1[i];
        ++k;
    }
}
gdjs.PerpusCode.GDDialogBoxdObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.PerpusCode.GDTargetRoundButtonObjects1.length;i<l;++i) {
    if ( gdjs.PerpusCode.GDTargetRoundButtonObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.PerpusCode.GDTargetRoundButtonObjects1[k] = gdjs.PerpusCode.GDTargetRoundButtonObjects1[i];
        ++k;
    }
}
gdjs.PerpusCode.GDTargetRoundButtonObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDDialogBoxdObjects1ObjectsGDgdjs_9546PerpusCode_9546GDTargetRoundButtonObjects1Objects, runtimeScene, false, false);
}
isConditionTrue_0 = !isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.PerpusCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs.PerpusCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDShadedDarkJoystickObjects1[i].TeleportAndPress((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.PerpusCode.GDPlayerObjects2});
gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.PerpusCode.GDPortalObjects2});
gdjs.PerpusCode.asyncCallback20626852 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PerpusCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Portal"), gdjs.PerpusCode.GDPortalObjects3);

{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, (gdjs.RuntimeObject.getVariableString(((gdjs.PerpusCode.GDPortalObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PerpusCode.GDPortalObjects3[0].getVariables()).getFromIndex(0))), false);
}gdjs.PerpusCode.localVariables.length = 0;
}
gdjs.PerpusCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PerpusCode.localVariables);
for (const obj of gdjs.PerpusCode.GDPortalObjects2) asyncObjectsList.addObject("Portal", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.PerpusCode.asyncCallback20626852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.PerpusCode.GDPlayerObjects1});
gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.PerpusCode.GDPortalObjects1});
gdjs.PerpusCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.PerpusCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PerpusCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.PerpusCode.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPlayerObjects2Objects, gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPortalObjects2Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20626020);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.PerpusCode.GDTransitionObjects2);
{for(var i = 0, len = gdjs.PerpusCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDTransitionObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PerpusCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDTransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PerpusCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PerpusCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.PerpusCode.GDPortalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPlayerObjects1Objects, gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPortalObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20628756);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PerpusCode.GDPlayerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(2), "Anda Harus Membaca CP ATP dahulu\nCP ATP Ada di rak buku\n");
}{for(var i = 0, len = gdjs.PerpusCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDPlayerObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (gdjs.PerpusCode.GDPlayerObjects1[i].getPointX("")) - 1, (gdjs.PerpusCode.GDPlayerObjects1[i].getPointY("")) + 4);
}
}
{ //Subevents
gdjs.PerpusCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.PerpusCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2)));
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.PerpusCode.GDDiaTextObjects1, gdjs.PerpusCode.GDDiaTextObjects2);

{for(var i = 0, len = gdjs.PerpusCode.GDDiaTextObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaTextObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getChild(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(2)));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueIcon"), gdjs.PerpusCode.GDContinueIconObjects1);
gdjs.copyArray(runtimeScene.getObjects("DiaBox"), gdjs.PerpusCode.GDDiaBoxObjects1);
/* Reuse gdjs.PerpusCode.GDDiaTextObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}{for(var i = 0, len = gdjs.PerpusCode.GDDiaBoxObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PerpusCode.GDDiaTextObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaTextObjects1[i].hide();
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(2));
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}{for(var i = 0, len = gdjs.PerpusCode.GDContinueIconObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDContinueIconObjects1[i].hide();
}
}}

}


};gdjs.PerpusCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20632084);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ContinueIcon"), gdjs.PerpusCode.GDContinueIconObjects2);
gdjs.copyArray(runtimeScene.getObjects("DiaBox"), gdjs.PerpusCode.GDDiaBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("DiaText"), gdjs.PerpusCode.GDDiaTextObjects2);
{for(var i = 0, len = gdjs.PerpusCode.GDDiaTextObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PerpusCode.GDDiaBoxObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaBoxObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PerpusCode.GDContinueIconObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDContinueIconObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PerpusCode.GDDiaTextObjects2.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaTextObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getChild(0).getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DiaText"), gdjs.PerpusCode.GDDiaTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PerpusCode.GDDiaTextObjects1.length;i<l;++i) {
    if ( gdjs.PerpusCode.GDDiaTextObjects1[i].getBehavior("AutoTyping").IsFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PerpusCode.GDDiaTextObjects1[k] = gdjs.PerpusCode.GDDiaTextObjects1[i];
        ++k;
    }
}
gdjs.PerpusCode.GDDiaTextObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20634716);
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{ //Subevents
gdjs.PerpusCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.PerpusCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bush1"), gdjs.PerpusCode.GDBush1Objects1);
gdjs.copyArray(runtimeScene.getObjects("ContinueIcon"), gdjs.PerpusCode.GDContinueIconObjects1);
gdjs.copyArray(runtimeScene.getObjects("DiaBox"), gdjs.PerpusCode.GDDiaBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("DiaText"), gdjs.PerpusCode.GDDiaTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.PerpusCode.GDEObjects1);
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.PerpusCode.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House2"), gdjs.PerpusCode.GDHouse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NPC"), gdjs.PerpusCode.GDNPCObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.PerpusCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.PerpusCode.GDPortalObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Ground"), gdjs.PerpusCode.GDTilemap_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Water"), gdjs.PerpusCode.GDTilemap_9595WaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.PerpusCode.GDTransitionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree1"), gdjs.PerpusCode.GDTree1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.PerpusCode.GDTree2Objects1);
gdjs.copyArray(runtimeScene.getObjects("ddd2"), gdjs.PerpusCode.GDddd2Objects1);
gdjs.copyArray(runtimeScene.getObjects("depan"), gdjs.PerpusCode.GDdepanObjects1);
gdjs.copyArray(runtimeScene.getObjects("meja"), gdjs.PerpusCode.GDmejaObjects1);
gdjs.copyArray(runtimeScene.getObjects("objek"), gdjs.PerpusCode.GDobjekObjects1);
{for(var i = 0, len = gdjs.PerpusCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Backward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 4, "", 0);
}{for(var i = 0, len = gdjs.PerpusCode.GDTree1Objects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDTree1Objects1[i].setZOrder((gdjs.PerpusCode.GDTree1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDBush1Objects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDBush1Objects1[i].setZOrder((gdjs.PerpusCode.GDBush1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDTree2Objects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDTree2Objects1[i].setZOrder((gdjs.PerpusCode.GDTree2Objects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDHouse1Objects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDHouse1Objects1[i].setZOrder((gdjs.PerpusCode.GDHouse1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDHouse2Objects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDHouse2Objects1[i].setZOrder((gdjs.PerpusCode.GDHouse2Objects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDNPCObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDNPCObjects1[i].setZOrder((gdjs.PerpusCode.GDNPCObjects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDTilemap_9595GroundObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDTilemap_9595GroundObjects1[i].setZOrder((gdjs.PerpusCode.GDTilemap_9595GroundObjects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDTilemap_9595WaterObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDTilemap_9595WaterObjects1[i].setZOrder((gdjs.PerpusCode.GDTilemap_9595WaterObjects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDNewSpriteObjects1[i].setZOrder((gdjs.PerpusCode.GDNewSpriteObjects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDobjekObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDobjekObjects1[i].setZOrder((gdjs.PerpusCode.GDobjekObjects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDdepanObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDdepanObjects1[i].setZOrder((gdjs.PerpusCode.GDdepanObjects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDmejaObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDmejaObjects1[i].setZOrder((gdjs.PerpusCode.GDmejaObjects1[i].getY()));
}
for(var i = 0, len = gdjs.PerpusCode.GDddd2Objects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDddd2Objects1[i].setZOrder((gdjs.PerpusCode.GDddd2Objects1[i].getY()));
}
}{for(var i = 0, len = gdjs.PerpusCode.GDEObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDEObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 0, 1, 10, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Layer");
}{for(var i = 0, len = gdjs.PerpusCode.GDDiaTextObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PerpusCode.GDDiaBoxObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDDiaBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PerpusCode.GDContinueIconObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDContinueIconObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PerpusCode.GDPortalObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDPortalObjects1[i].hide();
}
}}

}


{


gdjs.PerpusCode.eventsList0(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.PerpusCode.GDNewSprite2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PerpusCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDPlayerObjects1Objects, gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDNewSprite2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtsExt__SpriteMultitouchJoystick__IsButtonPressed.func(runtimeScene, 1, "A", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20617676);
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(2), "2Text ke 3");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(2), "2Text ke2");
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(2), "2Text1");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bush1"), gdjs.PerpusCode.GDBush1Objects1);
gdjs.copyArray(runtimeScene.getObjects("CameraTarget"), gdjs.PerpusCode.GDCameraTargetObjects1);
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.PerpusCode.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House2"), gdjs.PerpusCode.GDHouse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NPC"), gdjs.PerpusCode.GDNPCObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.PerpusCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PerpusCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Ground"), gdjs.PerpusCode.GDTilemap_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Water"), gdjs.PerpusCode.GDTilemap_9595WaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree1"), gdjs.PerpusCode.GDTree1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.PerpusCode.GDTree2Objects1);
gdjs.copyArray(runtimeScene.getObjects("ddd2"), gdjs.PerpusCode.GDddd2Objects1);
gdjs.copyArray(runtimeScene.getObjects("depan"), gdjs.PerpusCode.GDdepanObjects1);
gdjs.copyArray(runtimeScene.getObjects("meja"), gdjs.PerpusCode.GDmejaObjects1);
gdjs.copyArray(runtimeScene.getObjects("objek"), gdjs.PerpusCode.GDobjekObjects1);
{for(var i = 0, len = gdjs.PerpusCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.PerpusCode.mapOfGDgdjs_9546PerpusCode_9546GDTree1Objects1ObjectsGDgdjs_9546PerpusCode_9546GDBush1Objects1ObjectsGDgdjs_9546PerpusCode_9546GDTree2Objects1ObjectsGDgdjs_9546PerpusCode_9546GDHouse1Objects1ObjectsGDgdjs_9546PerpusCode_9546GDHouse2Objects1ObjectsGDgdjs_9546PerpusCode_9546GDNPCObjects1ObjectsGDgdjs_9546PerpusCode_9546GDTilemap_95959595GroundObjects1ObjectsGDgdjs_9546PerpusCode_9546GDTilemap_95959595WaterObjects1ObjectsGDgdjs_9546PerpusCode_9546GDNewSpriteObjects1ObjectsGDgdjs_9546PerpusCode_9546GDobjekObjects1ObjectsGDgdjs_9546PerpusCode_9546GDdepanObjects1ObjectsGDgdjs_9546PerpusCode_9546GDmejaObjects1ObjectsGDgdjs_9546PerpusCode_9546GDddd2Objects1Objects, false);
}
}{for(var i = 0, len = gdjs.PerpusCode.GDCameraTargetObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDCameraTargetObjects1[i].setX(gdjs.evtTools.common.lerp((gdjs.PerpusCode.GDCameraTargetObjects1[i].getPointX("")), (( gdjs.PerpusCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.PerpusCode.GDPlayerObjects1[0].getPointX("")), 0.05));
}
}{for(var i = 0, len = gdjs.PerpusCode.GDCameraTargetObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDCameraTargetObjects1[i].setY(gdjs.evtTools.common.lerp((gdjs.PerpusCode.GDCameraTargetObjects1[i].getPointY("")), (( gdjs.PerpusCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.PerpusCode.GDPlayerObjects1[0].getPointY("")), 0.05));
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.PerpusCode.GDCameraTargetObjects1.length !== 0 ? gdjs.PerpusCode.GDCameraTargetObjects1[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.PerpusCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PerpusCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.PerpusCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.PerpusCode.GDPlayerObjects1[k] = gdjs.PerpusCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.PerpusCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PerpusCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.PerpusCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.PerpusCode.GDPlayerObjects1[i].setAnimationFrame(0);
}
}}

}


{


gdjs.PerpusCode.eventsList2(runtimeScene);
}


{


gdjs.PerpusCode.eventsList5(runtimeScene);
}


{


gdjs.PerpusCode.eventsList7(runtimeScene);
}


};

gdjs.PerpusCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PerpusCode.GDDialogBoxdObjects1.length = 0;
gdjs.PerpusCode.GDDialogBoxdObjects2.length = 0;
gdjs.PerpusCode.GDDialogBoxdObjects3.length = 0;
gdjs.PerpusCode.GDPlayerObjects1.length = 0;
gdjs.PerpusCode.GDPlayerObjects2.length = 0;
gdjs.PerpusCode.GDPlayerObjects3.length = 0;
gdjs.PerpusCode.GDNPCObjects1.length = 0;
gdjs.PerpusCode.GDNPCObjects2.length = 0;
gdjs.PerpusCode.GDNPCObjects3.length = 0;
gdjs.PerpusCode.GDTree1Objects1.length = 0;
gdjs.PerpusCode.GDTree1Objects2.length = 0;
gdjs.PerpusCode.GDTree1Objects3.length = 0;
gdjs.PerpusCode.GDTree2Objects1.length = 0;
gdjs.PerpusCode.GDTree2Objects2.length = 0;
gdjs.PerpusCode.GDTree2Objects3.length = 0;
gdjs.PerpusCode.GDBush1Objects1.length = 0;
gdjs.PerpusCode.GDBush1Objects2.length = 0;
gdjs.PerpusCode.GDBush1Objects3.length = 0;
gdjs.PerpusCode.GDHouse1Objects1.length = 0;
gdjs.PerpusCode.GDHouse1Objects2.length = 0;
gdjs.PerpusCode.GDHouse1Objects3.length = 0;
gdjs.PerpusCode.GDHouse2Objects1.length = 0;
gdjs.PerpusCode.GDHouse2Objects2.length = 0;
gdjs.PerpusCode.GDHouse2Objects3.length = 0;
gdjs.PerpusCode.GDEObjects1.length = 0;
gdjs.PerpusCode.GDEObjects2.length = 0;
gdjs.PerpusCode.GDEObjects3.length = 0;
gdjs.PerpusCode.GDE2Objects1.length = 0;
gdjs.PerpusCode.GDE2Objects2.length = 0;
gdjs.PerpusCode.GDE2Objects3.length = 0;
gdjs.PerpusCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.PerpusCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.PerpusCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.PerpusCode.GDTargetRoundButtonObjects1.length = 0;
gdjs.PerpusCode.GDTargetRoundButtonObjects2.length = 0;
gdjs.PerpusCode.GDTargetRoundButtonObjects3.length = 0;
gdjs.PerpusCode.GDTilemap_9595GroundObjects1.length = 0;
gdjs.PerpusCode.GDTilemap_9595GroundObjects2.length = 0;
gdjs.PerpusCode.GDTilemap_9595GroundObjects3.length = 0;
gdjs.PerpusCode.GDTilemap_9595WaterObjects1.length = 0;
gdjs.PerpusCode.GDTilemap_9595WaterObjects2.length = 0;
gdjs.PerpusCode.GDTilemap_9595WaterObjects3.length = 0;
gdjs.PerpusCode.GDCameraTargetObjects1.length = 0;
gdjs.PerpusCode.GDCameraTargetObjects2.length = 0;
gdjs.PerpusCode.GDCameraTargetObjects3.length = 0;
gdjs.PerpusCode.GDTile_9595dalamObjects1.length = 0;
gdjs.PerpusCode.GDTile_9595dalamObjects2.length = 0;
gdjs.PerpusCode.GDTile_9595dalamObjects3.length = 0;
gdjs.PerpusCode.GDNewSpriteObjects1.length = 0;
gdjs.PerpusCode.GDNewSpriteObjects2.length = 0;
gdjs.PerpusCode.GDNewSpriteObjects3.length = 0;
gdjs.PerpusCode.GDdddObjects1.length = 0;
gdjs.PerpusCode.GDdddObjects2.length = 0;
gdjs.PerpusCode.GDdddObjects3.length = 0;
gdjs.PerpusCode.GDPortalObjects1.length = 0;
gdjs.PerpusCode.GDPortalObjects2.length = 0;
gdjs.PerpusCode.GDPortalObjects3.length = 0;
gdjs.PerpusCode.GDobjekObjects1.length = 0;
gdjs.PerpusCode.GDobjekObjects2.length = 0;
gdjs.PerpusCode.GDobjekObjects3.length = 0;
gdjs.PerpusCode.GDNewTileMapObjects1.length = 0;
gdjs.PerpusCode.GDNewTileMapObjects2.length = 0;
gdjs.PerpusCode.GDNewTileMapObjects3.length = 0;
gdjs.PerpusCode.GDmejaObjects1.length = 0;
gdjs.PerpusCode.GDmejaObjects2.length = 0;
gdjs.PerpusCode.GDmejaObjects3.length = 0;
gdjs.PerpusCode.GDdepanObjects1.length = 0;
gdjs.PerpusCode.GDdepanObjects2.length = 0;
gdjs.PerpusCode.GDdepanObjects3.length = 0;
gdjs.PerpusCode.GDmakanObjects1.length = 0;
gdjs.PerpusCode.GDmakanObjects2.length = 0;
gdjs.PerpusCode.GDmakanObjects3.length = 0;
gdjs.PerpusCode.GDddd2Objects1.length = 0;
gdjs.PerpusCode.GDddd2Objects2.length = 0;
gdjs.PerpusCode.GDddd2Objects3.length = 0;
gdjs.PerpusCode.GD_95951Objects1.length = 0;
gdjs.PerpusCode.GD_95951Objects2.length = 0;
gdjs.PerpusCode.GD_95951Objects3.length = 0;
gdjs.PerpusCode.GDNewSprite2Objects1.length = 0;
gdjs.PerpusCode.GDNewSprite2Objects2.length = 0;
gdjs.PerpusCode.GDNewSprite2Objects3.length = 0;
gdjs.PerpusCode.GDDialogueObjects1.length = 0;
gdjs.PerpusCode.GDDialogueObjects2.length = 0;
gdjs.PerpusCode.GDDialogueObjects3.length = 0;
gdjs.PerpusCode.GDDiaBoxObjects1.length = 0;
gdjs.PerpusCode.GDDiaBoxObjects2.length = 0;
gdjs.PerpusCode.GDDiaBoxObjects3.length = 0;
gdjs.PerpusCode.GDDiaTextObjects1.length = 0;
gdjs.PerpusCode.GDDiaTextObjects2.length = 0;
gdjs.PerpusCode.GDDiaTextObjects3.length = 0;
gdjs.PerpusCode.GDIndicatorObjects1.length = 0;
gdjs.PerpusCode.GDIndicatorObjects2.length = 0;
gdjs.PerpusCode.GDIndicatorObjects3.length = 0;
gdjs.PerpusCode.GDContinueIconObjects1.length = 0;
gdjs.PerpusCode.GDContinueIconObjects2.length = 0;
gdjs.PerpusCode.GDContinueIconObjects3.length = 0;
gdjs.PerpusCode.GDDialogue2Objects1.length = 0;
gdjs.PerpusCode.GDDialogue2Objects2.length = 0;
gdjs.PerpusCode.GDDialogue2Objects3.length = 0;
gdjs.PerpusCode.GDTransitionObjects1.length = 0;
gdjs.PerpusCode.GDTransitionObjects2.length = 0;
gdjs.PerpusCode.GDTransitionObjects3.length = 0;

gdjs.PerpusCode.eventsList8(runtimeScene);
gdjs.PerpusCode.GDDialogBoxdObjects1.length = 0;
gdjs.PerpusCode.GDDialogBoxdObjects2.length = 0;
gdjs.PerpusCode.GDDialogBoxdObjects3.length = 0;
gdjs.PerpusCode.GDPlayerObjects1.length = 0;
gdjs.PerpusCode.GDPlayerObjects2.length = 0;
gdjs.PerpusCode.GDPlayerObjects3.length = 0;
gdjs.PerpusCode.GDNPCObjects1.length = 0;
gdjs.PerpusCode.GDNPCObjects2.length = 0;
gdjs.PerpusCode.GDNPCObjects3.length = 0;
gdjs.PerpusCode.GDTree1Objects1.length = 0;
gdjs.PerpusCode.GDTree1Objects2.length = 0;
gdjs.PerpusCode.GDTree1Objects3.length = 0;
gdjs.PerpusCode.GDTree2Objects1.length = 0;
gdjs.PerpusCode.GDTree2Objects2.length = 0;
gdjs.PerpusCode.GDTree2Objects3.length = 0;
gdjs.PerpusCode.GDBush1Objects1.length = 0;
gdjs.PerpusCode.GDBush1Objects2.length = 0;
gdjs.PerpusCode.GDBush1Objects3.length = 0;
gdjs.PerpusCode.GDHouse1Objects1.length = 0;
gdjs.PerpusCode.GDHouse1Objects2.length = 0;
gdjs.PerpusCode.GDHouse1Objects3.length = 0;
gdjs.PerpusCode.GDHouse2Objects1.length = 0;
gdjs.PerpusCode.GDHouse2Objects2.length = 0;
gdjs.PerpusCode.GDHouse2Objects3.length = 0;
gdjs.PerpusCode.GDEObjects1.length = 0;
gdjs.PerpusCode.GDEObjects2.length = 0;
gdjs.PerpusCode.GDEObjects3.length = 0;
gdjs.PerpusCode.GDE2Objects1.length = 0;
gdjs.PerpusCode.GDE2Objects2.length = 0;
gdjs.PerpusCode.GDE2Objects3.length = 0;
gdjs.PerpusCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.PerpusCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.PerpusCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.PerpusCode.GDTargetRoundButtonObjects1.length = 0;
gdjs.PerpusCode.GDTargetRoundButtonObjects2.length = 0;
gdjs.PerpusCode.GDTargetRoundButtonObjects3.length = 0;
gdjs.PerpusCode.GDTilemap_9595GroundObjects1.length = 0;
gdjs.PerpusCode.GDTilemap_9595GroundObjects2.length = 0;
gdjs.PerpusCode.GDTilemap_9595GroundObjects3.length = 0;
gdjs.PerpusCode.GDTilemap_9595WaterObjects1.length = 0;
gdjs.PerpusCode.GDTilemap_9595WaterObjects2.length = 0;
gdjs.PerpusCode.GDTilemap_9595WaterObjects3.length = 0;
gdjs.PerpusCode.GDCameraTargetObjects1.length = 0;
gdjs.PerpusCode.GDCameraTargetObjects2.length = 0;
gdjs.PerpusCode.GDCameraTargetObjects3.length = 0;
gdjs.PerpusCode.GDTile_9595dalamObjects1.length = 0;
gdjs.PerpusCode.GDTile_9595dalamObjects2.length = 0;
gdjs.PerpusCode.GDTile_9595dalamObjects3.length = 0;
gdjs.PerpusCode.GDNewSpriteObjects1.length = 0;
gdjs.PerpusCode.GDNewSpriteObjects2.length = 0;
gdjs.PerpusCode.GDNewSpriteObjects3.length = 0;
gdjs.PerpusCode.GDdddObjects1.length = 0;
gdjs.PerpusCode.GDdddObjects2.length = 0;
gdjs.PerpusCode.GDdddObjects3.length = 0;
gdjs.PerpusCode.GDPortalObjects1.length = 0;
gdjs.PerpusCode.GDPortalObjects2.length = 0;
gdjs.PerpusCode.GDPortalObjects3.length = 0;
gdjs.PerpusCode.GDobjekObjects1.length = 0;
gdjs.PerpusCode.GDobjekObjects2.length = 0;
gdjs.PerpusCode.GDobjekObjects3.length = 0;
gdjs.PerpusCode.GDNewTileMapObjects1.length = 0;
gdjs.PerpusCode.GDNewTileMapObjects2.length = 0;
gdjs.PerpusCode.GDNewTileMapObjects3.length = 0;
gdjs.PerpusCode.GDmejaObjects1.length = 0;
gdjs.PerpusCode.GDmejaObjects2.length = 0;
gdjs.PerpusCode.GDmejaObjects3.length = 0;
gdjs.PerpusCode.GDdepanObjects1.length = 0;
gdjs.PerpusCode.GDdepanObjects2.length = 0;
gdjs.PerpusCode.GDdepanObjects3.length = 0;
gdjs.PerpusCode.GDmakanObjects1.length = 0;
gdjs.PerpusCode.GDmakanObjects2.length = 0;
gdjs.PerpusCode.GDmakanObjects3.length = 0;
gdjs.PerpusCode.GDddd2Objects1.length = 0;
gdjs.PerpusCode.GDddd2Objects2.length = 0;
gdjs.PerpusCode.GDddd2Objects3.length = 0;
gdjs.PerpusCode.GD_95951Objects1.length = 0;
gdjs.PerpusCode.GD_95951Objects2.length = 0;
gdjs.PerpusCode.GD_95951Objects3.length = 0;
gdjs.PerpusCode.GDNewSprite2Objects1.length = 0;
gdjs.PerpusCode.GDNewSprite2Objects2.length = 0;
gdjs.PerpusCode.GDNewSprite2Objects3.length = 0;
gdjs.PerpusCode.GDDialogueObjects1.length = 0;
gdjs.PerpusCode.GDDialogueObjects2.length = 0;
gdjs.PerpusCode.GDDialogueObjects3.length = 0;
gdjs.PerpusCode.GDDiaBoxObjects1.length = 0;
gdjs.PerpusCode.GDDiaBoxObjects2.length = 0;
gdjs.PerpusCode.GDDiaBoxObjects3.length = 0;
gdjs.PerpusCode.GDDiaTextObjects1.length = 0;
gdjs.PerpusCode.GDDiaTextObjects2.length = 0;
gdjs.PerpusCode.GDDiaTextObjects3.length = 0;
gdjs.PerpusCode.GDIndicatorObjects1.length = 0;
gdjs.PerpusCode.GDIndicatorObjects2.length = 0;
gdjs.PerpusCode.GDIndicatorObjects3.length = 0;
gdjs.PerpusCode.GDContinueIconObjects1.length = 0;
gdjs.PerpusCode.GDContinueIconObjects2.length = 0;
gdjs.PerpusCode.GDContinueIconObjects3.length = 0;
gdjs.PerpusCode.GDDialogue2Objects1.length = 0;
gdjs.PerpusCode.GDDialogue2Objects2.length = 0;
gdjs.PerpusCode.GDDialogue2Objects3.length = 0;
gdjs.PerpusCode.GDTransitionObjects1.length = 0;
gdjs.PerpusCode.GDTransitionObjects2.length = 0;
gdjs.PerpusCode.GDTransitionObjects3.length = 0;


return;

}

gdjs['PerpusCode'] = gdjs.PerpusCode;
