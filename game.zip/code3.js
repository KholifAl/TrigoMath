gdjs.Level1Code = {};
gdjs.Level1Code.localVariables = [];
gdjs.Level1Code.forEachCount0_2 = 0;

gdjs.Level1Code.forEachCount1_2 = 0;

gdjs.Level1Code.forEachIndex2 = 0;

gdjs.Level1Code.forEachObjects2 = [];

gdjs.Level1Code.forEachTotalCount2 = 0;

gdjs.Level1Code.GDDialogBoxdObjects1= [];
gdjs.Level1Code.GDDialogBoxdObjects2= [];
gdjs.Level1Code.GDDialogBoxdObjects3= [];
gdjs.Level1Code.GDDialogBoxdObjects4= [];
gdjs.Level1Code.GDNPCObjects1= [];
gdjs.Level1Code.GDNPCObjects2= [];
gdjs.Level1Code.GDNPCObjects3= [];
gdjs.Level1Code.GDNPCObjects4= [];
gdjs.Level1Code.GDTree1Objects1= [];
gdjs.Level1Code.GDTree1Objects2= [];
gdjs.Level1Code.GDTree1Objects3= [];
gdjs.Level1Code.GDTree1Objects4= [];
gdjs.Level1Code.GDTree2Objects1= [];
gdjs.Level1Code.GDTree2Objects2= [];
gdjs.Level1Code.GDTree2Objects3= [];
gdjs.Level1Code.GDTree2Objects4= [];
gdjs.Level1Code.GDBush1Objects1= [];
gdjs.Level1Code.GDBush1Objects2= [];
gdjs.Level1Code.GDBush1Objects3= [];
gdjs.Level1Code.GDBush1Objects4= [];
gdjs.Level1Code.GDHouse1Objects1= [];
gdjs.Level1Code.GDHouse1Objects2= [];
gdjs.Level1Code.GDHouse1Objects3= [];
gdjs.Level1Code.GDHouse1Objects4= [];
gdjs.Level1Code.GDHouse2Objects1= [];
gdjs.Level1Code.GDHouse2Objects2= [];
gdjs.Level1Code.GDHouse2Objects3= [];
gdjs.Level1Code.GDHouse2Objects4= [];
gdjs.Level1Code.GDEObjects1= [];
gdjs.Level1Code.GDEObjects2= [];
gdjs.Level1Code.GDEObjects3= [];
gdjs.Level1Code.GDEObjects4= [];
gdjs.Level1Code.GDE2Objects1= [];
gdjs.Level1Code.GDE2Objects2= [];
gdjs.Level1Code.GDE2Objects3= [];
gdjs.Level1Code.GDE2Objects4= [];
gdjs.Level1Code.GDShadedDarkJoystickObjects1= [];
gdjs.Level1Code.GDShadedDarkJoystickObjects2= [];
gdjs.Level1Code.GDShadedDarkJoystickObjects3= [];
gdjs.Level1Code.GDShadedDarkJoystickObjects4= [];
gdjs.Level1Code.GDTargetRoundButtonObjects1= [];
gdjs.Level1Code.GDTargetRoundButtonObjects2= [];
gdjs.Level1Code.GDTargetRoundButtonObjects3= [];
gdjs.Level1Code.GDTargetRoundButtonObjects4= [];
gdjs.Level1Code.GDTilemap_9595GroundObjects1= [];
gdjs.Level1Code.GDTilemap_9595GroundObjects2= [];
gdjs.Level1Code.GDTilemap_9595GroundObjects3= [];
gdjs.Level1Code.GDTilemap_9595GroundObjects4= [];
gdjs.Level1Code.GDTilemap_9595WaterObjects1= [];
gdjs.Level1Code.GDTilemap_9595WaterObjects2= [];
gdjs.Level1Code.GDTilemap_9595WaterObjects3= [];
gdjs.Level1Code.GDTilemap_9595WaterObjects4= [];
gdjs.Level1Code.GDCameraTargetObjects1= [];
gdjs.Level1Code.GDCameraTargetObjects2= [];
gdjs.Level1Code.GDCameraTargetObjects3= [];
gdjs.Level1Code.GDCameraTargetObjects4= [];
gdjs.Level1Code.GDPortalObjects1= [];
gdjs.Level1Code.GDPortalObjects2= [];
gdjs.Level1Code.GDPortalObjects3= [];
gdjs.Level1Code.GDPortalObjects4= [];
gdjs.Level1Code.GDPlayerObjects1= [];
gdjs.Level1Code.GDPlayerObjects2= [];
gdjs.Level1Code.GDPlayerObjects3= [];
gdjs.Level1Code.GDPlayerObjects4= [];
gdjs.Level1Code.GDMusuhObjects1= [];
gdjs.Level1Code.GDMusuhObjects2= [];
gdjs.Level1Code.GDMusuhObjects3= [];
gdjs.Level1Code.GDMusuhObjects4= [];
gdjs.Level1Code.GDNewSpriteObjects1= [];
gdjs.Level1Code.GDNewSpriteObjects2= [];
gdjs.Level1Code.GDNewSpriteObjects3= [];
gdjs.Level1Code.GDNewSpriteObjects4= [];
gdjs.Level1Code.GDDebugTextObjects1= [];
gdjs.Level1Code.GDDebugTextObjects2= [];
gdjs.Level1Code.GDDebugTextObjects3= [];
gdjs.Level1Code.GDDebugTextObjects4= [];
gdjs.Level1Code.GDtpObjects1= [];
gdjs.Level1Code.GDtpObjects2= [];
gdjs.Level1Code.GDtpObjects3= [];
gdjs.Level1Code.GDtpObjects4= [];
gdjs.Level1Code.GDDebugText2Objects1= [];
gdjs.Level1Code.GDDebugText2Objects2= [];
gdjs.Level1Code.GDDebugText2Objects3= [];
gdjs.Level1Code.GDDebugText2Objects4= [];
gdjs.Level1Code.GDMusuh2Objects1= [];
gdjs.Level1Code.GDMusuh2Objects2= [];
gdjs.Level1Code.GDMusuh2Objects3= [];
gdjs.Level1Code.GDMusuh2Objects4= [];
gdjs.Level1Code.GDTransitionObjects1= [];
gdjs.Level1Code.GDTransitionObjects2= [];
gdjs.Level1Code.GDTransitionObjects3= [];
gdjs.Level1Code.GDTransitionObjects4= [];


gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDTree1Objects1ObjectsGDgdjs_9546Level1Code_9546GDBush1Objects1ObjectsGDgdjs_9546Level1Code_9546GDTree2Objects1ObjectsGDgdjs_9546Level1Code_9546GDHouse1Objects1ObjectsGDgdjs_9546Level1Code_9546GDHouse2Objects1ObjectsGDgdjs_9546Level1Code_9546GDNPCObjects1ObjectsGDgdjs_9546Level1Code_9546GDTilemap_95959595GroundObjects1ObjectsGDgdjs_9546Level1Code_9546GDTilemap_95959595WaterObjects1Objects = Hashtable.newFrom({"Tree1": gdjs.Level1Code.GDTree1Objects1, "Bush1": gdjs.Level1Code.GDBush1Objects1, "Tree2": gdjs.Level1Code.GDTree2Objects1, "House1": gdjs.Level1Code.GDHouse1Objects1, "House2": gdjs.Level1Code.GDHouse2Objects1, "NPC": gdjs.Level1Code.GDNPCObjects1, "Tilemap_Ground": gdjs.Level1Code.GDTilemap_9595GroundObjects1, "Tilemap_Water": gdjs.Level1Code.GDTilemap_9595WaterObjects1});
gdjs.Level1Code.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDMusuhObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuhObjects1.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDMusuhObjects1[i].getBehavior("Pathfinding").pathFound()) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuhObjects1[k] = gdjs.Level1Code.GDMusuhObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuhObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDDebugTextObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDDebugTextObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDebugTextObjects1[i].getBehavior("Text").setText("gabisaa");
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDNPCObjects2Objects = Hashtable.newFrom({"NPC": gdjs.Level1Code.GDNPCObjects2});
gdjs.Level1Code.asyncCallback21236324 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Level1Code.localVariables);
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Battle");
}gdjs.Level1Code.localVariables.length = 0;
}
gdjs.Level1Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Level1Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.25), (runtimeScene) => (gdjs.Level1Code.asyncCallback21236324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level1Code.GDDialogBoxdObjects2, gdjs.Level1Code.GDDialogBoxdObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDialogBoxdObjects3.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDialogBoxdObjects3[i].IsYesClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDialogBoxdObjects3[k] = gdjs.Level1Code.GDDialogBoxdObjects3[i];
        ++k;
    }
}
gdjs.Level1Code.GDDialogBoxdObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Level1Code.GDTransitionObjects3);
{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level1Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level1Code.GDDialogBoxdObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDialogBoxdObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDialogBoxdObjects2[i].IsNoClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDialogBoxdObjects2[k] = gdjs.Level1Code.GDDialogBoxdObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDDialogBoxdObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDDialogBoxdObjects2 */
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.Level1Code.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDDialogBoxdObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDialogBoxdObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDEObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDEObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}}

}


};gdjs.Level1Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NPC"), gdjs.Level1Code.GDNPCObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtsExt__SpriteMultitouchJoystick__IsButtonPressed.func(runtimeScene, 1, "A", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21233844);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDNPCObjects2Objects, 20, false);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DialogBoxd"), gdjs.Level1Code.GDDialogBoxdObjects2);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.Level1Code.GDEObjects2);
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDDialogBoxdObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDialogBoxdObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDEObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDEObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DialogBoxd"), gdjs.Level1Code.GDDialogBoxdObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDialogBoxdObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDialogBoxdObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDDialogBoxdObjects2[k] = gdjs.Level1Code.GDDialogBoxdObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDDialogBoxdObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level1Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DialogBoxd"), gdjs.Level1Code.GDDialogBoxdObjects1);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.Level1Code.GDEObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Level1Code.GDTransitionObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDDialogBoxdObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDialogBoxdObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDEObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDEObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].activateBehavior("TopDownMovement", true);
}
}}

}


};gdjs.Level1Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDShadedDarkJoystickObjects2 */
gdjs.copyArray(runtimeScene.getObjects("TargetRoundButton"), gdjs.Level1Code.GDTargetRoundButtonObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShadedDarkJoystickObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDTargetRoundButtonObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDTargetRoundButtonObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDDialogBoxdObjects2ObjectsGDgdjs_9546Level1Code_9546GDTargetRoundButtonObjects2Objects = Hashtable.newFrom({"DialogBoxd": gdjs.Level1Code.GDDialogBoxdObjects2, "TargetRoundButton": gdjs.Level1Code.GDTargetRoundButtonObjects2});
gdjs.Level1Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.Level1Code.GDShadedDarkJoystickObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShadedDarkJoystickObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level1Code.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShadedDarkJoystickObjects2[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level1Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DialogBoxd"), gdjs.Level1Code.GDDialogBoxdObjects2);
gdjs.copyArray(runtimeScene.getObjects("TargetRoundButton"), gdjs.Level1Code.GDTargetRoundButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDDialogBoxdObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDDialogBoxdObjects2[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Level1Code.GDDialogBoxdObjects2[k] = gdjs.Level1Code.GDDialogBoxdObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDDialogBoxdObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDTargetRoundButtonObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDTargetRoundButtonObjects2[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Level1Code.GDTargetRoundButtonObjects2[k] = gdjs.Level1Code.GDTargetRoundButtonObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDTargetRoundButtonObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDDialogBoxdObjects2ObjectsGDgdjs_9546Level1Code_9546GDTargetRoundButtonObjects2Objects, runtimeScene, false, false);
}
isConditionTrue_0 = !isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.Level1Code.GDShadedDarkJoystickObjects2);
{for(var i = 0, len = gdjs.Level1Code.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDShadedDarkJoystickObjects2[i].TeleportAndPress((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.Level1Code.GDPortalObjects1});
gdjs.Level1Code.asyncCallback21242996 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Level1Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Perpus", false);
}gdjs.Level1Code.localVariables.length = 0;
}
gdjs.Level1Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Level1Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level1Code.asyncCallback21242996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMusuhObjects2ObjectsGDgdjs_9546Level1Code_9546GDMusuh2Objects2Objects = Hashtable.newFrom({"Musuh": gdjs.Level1Code.GDMusuhObjects2, "Musuh2": gdjs.Level1Code.GDMusuh2Objects2});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects2});
gdjs.Level1Code.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.Level1Code.GDMusuhObjects2 */
/* Reuse gdjs.Level1Code.GDMusuh2Objects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuhObjects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDMusuhObjects2[i].getBehavior("Pathfinding").pathFound()) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuhObjects2[k] = gdjs.Level1Code.GDMusuhObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuhObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuh2Objects2.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDMusuh2Objects2[i].getBehavior("Pathfinding").pathFound()) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuh2Objects2[k] = gdjs.Level1Code.GDMusuh2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuh2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDDebugText2Objects2 */
/* Reuse gdjs.Level1Code.GDMusuhObjects2 */
/* Reuse gdjs.Level1Code.GDMusuh2Objects2 */
{for(var i = 0, len = gdjs.Level1Code.GDDebugText2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDebugText2Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString());
}
}{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects2[i].returnVariable(gdjs.Level1Code.GDMusuhObjects2[i].getVariables().get("isEscaping")).setBoolean(false);
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects2[i].returnVariable(gdjs.Level1Code.GDMusuh2Objects2[i].getVariables().get("isEscaping")).setBoolean(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects2[i].returnVariable(gdjs.Level1Code.GDMusuhObjects2[i].getVariables().get("EscapeCounter")).sub(1);
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects2[i].returnVariable(gdjs.Level1Code.GDMusuh2Objects2[i].getVariables().get("EscapeCounter")).sub(1);
}
}}

}


};gdjs.Level1Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Musuh"), gdjs.Level1Code.GDMusuhObjects2);
gdjs.copyArray(runtimeScene.getObjects("Musuh2"), gdjs.Level1Code.GDMusuh2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects2);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("Ketemu", variable);
}
gdjs.Level1Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMusuhObjects2ObjectsGDgdjs_9546Level1Code_9546GDMusuh2Objects2Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects2Objects, 50, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuhObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuhObjects2[i].getVariableNumber(gdjs.Level1Code.GDMusuhObjects2[i].getVariables().get("EscapeCounter")) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuhObjects2[k] = gdjs.Level1Code.GDMusuhObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuhObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuh2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuh2Objects2[i].getVariableNumber(gdjs.Level1Code.GDMusuh2Objects2[i].getVariables().get("EscapeCounter")) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuh2Objects2[k] = gdjs.Level1Code.GDMusuh2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuh2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuhObjects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuhObjects2[i].getVariableBoolean(gdjs.Level1Code.GDMusuhObjects2[i].getVariables().get("isEscaping"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuhObjects2[k] = gdjs.Level1Code.GDMusuhObjects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuhObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuh2Objects2.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuh2Objects2[i].getVariableBoolean(gdjs.Level1Code.GDMusuh2Objects2[i].getVariables().get("isEscaping"), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuh2Objects2[k] = gdjs.Level1Code.GDMusuh2Objects2[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuh2Objects2.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DebugText"), gdjs.Level1Code.GDDebugTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("DebugText2"), gdjs.Level1Code.GDDebugText2Objects2);
/* Reuse gdjs.Level1Code.GDMusuhObjects2 */
/* Reuse gdjs.Level1Code.GDMusuh2Objects2 */
/* Reuse gdjs.Level1Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects2[i].returnVariable(gdjs.Level1Code.GDMusuhObjects2[i].getVariables().get("isEscaping")).setBoolean(true);
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects2[i].returnVariable(gdjs.Level1Code.GDMusuh2Objects2[i].getVariables().get("isEscaping")).setBoolean(true);
}
}{for(var i = 0, len = gdjs.Level1Code.GDDebugTextObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDebugTextObjects2[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getAsString());
}
}{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects2[i].returnVariable(gdjs.Level1Code.GDMusuhObjects2[i].getVariables().get("EscapeCounter")).add(1);
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects2[i].returnVariable(gdjs.Level1Code.GDMusuh2Objects2[i].getVariables().get("EscapeCounter")).add(1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber((( gdjs.Level1Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects2[0].getPointX("")) + (150 * Math.cos(gdjs.randomInRange(150, 210))));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber((( gdjs.Level1Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects2[0].getPointY("")) + (150 * Math.sin(gdjs.randomInRange(150, 210))));
}{for(var i = 0, len = gdjs.Level1Code.GDDebugText2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDebugText2Objects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.Level1Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects2[0].getZOrder())));
}
}{for(var i = 0, len = gdjs.Level1Code.GDDebugTextObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDDebugTextObjects2[i].getBehavior("Text").setText("bisaa");
}
}{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects2[i].getBehavior("Pathfinding").setMaxSpeed(1000);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}
{ //Subevents
gdjs.Level1Code.eventsList7(runtimeScene);} //End of subevents
}
gdjs.Level1Code.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("Musuh"), gdjs.Level1Code.GDMusuhObjects1);
gdjs.copyArray(runtimeScene.getObjects("Musuh2"), gdjs.Level1Code.GDMusuh2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuhObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuhObjects1[i].getVariableBoolean(gdjs.Level1Code.GDMusuhObjects1[i].getVariables().get("isEscaping"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuhObjects1[k] = gdjs.Level1Code.GDMusuhObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuhObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuh2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuh2Objects1[i].getVariableBoolean(gdjs.Level1Code.GDMusuh2Objects1[i].getVariables().get("isEscaping"), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuh2Objects1[k] = gdjs.Level1Code.GDMusuh2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuh2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuhObjects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuhObjects1[i].getBehavior("Pathfinding").destinationReached() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuhObjects1[k] = gdjs.Level1Code.GDMusuhObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuhObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDMusuh2Objects1.length;i<l;++i) {
    if ( gdjs.Level1Code.GDMusuh2Objects1[i].getBehavior("Pathfinding").destinationReached() ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDMusuh2Objects1[k] = gdjs.Level1Code.GDMusuh2Objects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDMusuh2Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMusuhObjects1 */
/* Reuse gdjs.Level1Code.GDMusuh2Objects1 */
{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects1[i].returnVariable(gdjs.Level1Code.GDMusuhObjects1[i].getVariables().get("isEscaping")).setBoolean(false);
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects1[i].returnVariable(gdjs.Level1Code.GDMusuh2Objects1[i].getVariables().get("isEscaping")).setBoolean(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects1[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects1[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
}}

}


};gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMusuhObjects1ObjectsGDgdjs_9546Level1Code_9546GDMusuh2Objects1Objects = Hashtable.newFrom({"Musuh": gdjs.Level1Code.GDMusuhObjects1, "Musuh2": gdjs.Level1Code.GDMusuh2Objects1});
gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level1Code.GDPlayerObjects1});
gdjs.Level1Code.asyncCallback21251212 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Level1Code.localVariables);
gdjs.Level1Code.localVariables.length = 0;
}
gdjs.Level1Code.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Level1Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.25), (runtimeScene) => (gdjs.Level1Code.asyncCallback21251212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level1Code.eventsList10 = function(runtimeScene) {

};gdjs.Level1Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Musuh"), gdjs.Level1Code.GDMusuhObjects1);
gdjs.copyArray(runtimeScene.getObjects("Musuh2"), gdjs.Level1Code.GDMusuh2Objects1);

gdjs.Level1Code.forEachTotalCount2 = 0;
gdjs.Level1Code.forEachObjects2.length = 0;
gdjs.Level1Code.forEachCount0_2 = gdjs.Level1Code.GDMusuhObjects1.length;
gdjs.Level1Code.forEachTotalCount2 += gdjs.Level1Code.forEachCount0_2;
gdjs.Level1Code.forEachObjects2.push.apply(gdjs.Level1Code.forEachObjects2,gdjs.Level1Code.GDMusuhObjects1);
gdjs.Level1Code.forEachCount1_2 = gdjs.Level1Code.GDMusuh2Objects1.length;
gdjs.Level1Code.forEachTotalCount2 += gdjs.Level1Code.forEachCount1_2;
gdjs.Level1Code.forEachObjects2.push.apply(gdjs.Level1Code.forEachObjects2,gdjs.Level1Code.GDMusuh2Objects1);
for (gdjs.Level1Code.forEachIndex2 = 0;gdjs.Level1Code.forEachIndex2 < gdjs.Level1Code.forEachTotalCount2;++gdjs.Level1Code.forEachIndex2) {
gdjs.Level1Code.GDMusuhObjects2.length = 0;

gdjs.Level1Code.GDMusuh2Objects2.length = 0;


if (gdjs.Level1Code.forEachIndex2 < gdjs.Level1Code.forEachCount0_2) {
    gdjs.Level1Code.GDMusuhObjects2.push(gdjs.Level1Code.forEachObjects2[gdjs.Level1Code.forEachIndex2]);
}
else if (gdjs.Level1Code.forEachIndex2 < gdjs.Level1Code.forEachCount0_2+gdjs.Level1Code.forEachCount1_2) {
    gdjs.Level1Code.GDMusuh2Objects2.push(gdjs.Level1Code.forEachObjects2[gdjs.Level1Code.forEachIndex2]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == (( gdjs.Level1Code.GDMusuh2Objects2.length === 0 ) ? (( gdjs.Level1Code.GDMusuhObjects2.length === 0 ) ? 0 :gdjs.Level1Code.GDMusuhObjects2[0].getZOrder()) :gdjs.Level1Code.GDMusuh2Objects2[0].getZOrder()));
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level1Code.GDMusuh2Objects2.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuh2Objects2[i].deleteFromScene(runtimeScene);
}
}}
}

}


};gdjs.Level1Code.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bush1"), gdjs.Level1Code.GDBush1Objects1);
gdjs.copyArray(runtimeScene.getObjects("DialogBoxd"), gdjs.Level1Code.GDDialogBoxdObjects1);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.Level1Code.GDEObjects1);
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.Level1Code.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House2"), gdjs.Level1Code.GDHouse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NPC"), gdjs.Level1Code.GDNPCObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Ground"), gdjs.Level1Code.GDTilemap_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Water"), gdjs.Level1Code.GDTilemap_9595WaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Level1Code.GDTransitionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree1"), gdjs.Level1Code.GDTree1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.Level1Code.GDTree2Objects1);
{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Backward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 4, "", 0);
}{for(var i = 0, len = gdjs.Level1Code.GDTree1Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTree1Objects1[i].setZOrder((gdjs.Level1Code.GDTree1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.Level1Code.GDBush1Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDBush1Objects1[i].setZOrder((gdjs.Level1Code.GDBush1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.Level1Code.GDTree2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTree2Objects1[i].setZOrder((gdjs.Level1Code.GDTree2Objects1[i].getY()));
}
for(var i = 0, len = gdjs.Level1Code.GDHouse1Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHouse1Objects1[i].setZOrder((gdjs.Level1Code.GDHouse1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.Level1Code.GDHouse2Objects1.length ;i < len;++i) {
    gdjs.Level1Code.GDHouse2Objects1[i].setZOrder((gdjs.Level1Code.GDHouse2Objects1[i].getY()));
}
for(var i = 0, len = gdjs.Level1Code.GDNPCObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDNPCObjects1[i].setZOrder((gdjs.Level1Code.GDNPCObjects1[i].getY()));
}
for(var i = 0, len = gdjs.Level1Code.GDTilemap_9595GroundObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTilemap_9595GroundObjects1[i].setZOrder((gdjs.Level1Code.GDTilemap_9595GroundObjects1[i].getY()));
}
for(var i = 0, len = gdjs.Level1Code.GDTilemap_9595WaterObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTilemap_9595WaterObjects1[i].setZOrder((gdjs.Level1Code.GDTilemap_9595WaterObjects1[i].getY()));
}
}{for(var i = 0, len = gdjs.Level1Code.GDEObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDEObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 0, 1, 10, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Level1Code.GDDialogBoxdObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDialogBoxdObjects1[i].hide();
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(2);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bush1"), gdjs.Level1Code.GDBush1Objects1);
gdjs.copyArray(runtimeScene.getObjects("CameraTarget"), gdjs.Level1Code.GDCameraTargetObjects1);
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.Level1Code.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House2"), gdjs.Level1Code.GDHouse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Musuh"), gdjs.Level1Code.GDMusuhObjects1);
gdjs.copyArray(runtimeScene.getObjects("NPC"), gdjs.Level1Code.GDNPCObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Ground"), gdjs.Level1Code.GDTilemap_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Water"), gdjs.Level1Code.GDTilemap_9595WaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree1"), gdjs.Level1Code.GDTree1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.Level1Code.GDTree2Objects1);
{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects1[i].setZOrder((gdjs.Level1Code.GDMusuhObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].separateFromObjectsList(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDTree1Objects1ObjectsGDgdjs_9546Level1Code_9546GDBush1Objects1ObjectsGDgdjs_9546Level1Code_9546GDTree2Objects1ObjectsGDgdjs_9546Level1Code_9546GDHouse1Objects1ObjectsGDgdjs_9546Level1Code_9546GDHouse2Objects1ObjectsGDgdjs_9546Level1Code_9546GDNPCObjects1ObjectsGDgdjs_9546Level1Code_9546GDTilemap_95959595GroundObjects1ObjectsGDgdjs_9546Level1Code_9546GDTilemap_95959595WaterObjects1Objects, false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDCameraTargetObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDCameraTargetObjects1[i].setX(gdjs.evtTools.common.lerp((gdjs.Level1Code.GDCameraTargetObjects1[i].getPointX("")), (( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointX("")), 0.05));
}
}{for(var i = 0, len = gdjs.Level1Code.GDCameraTargetObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDCameraTargetObjects1[i].setY(gdjs.evtTools.common.lerp((gdjs.Level1Code.GDCameraTargetObjects1[i].getPointY("")), (( gdjs.Level1Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDPlayerObjects1[0].getPointY("")), 0.05));
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Level1Code.GDCameraTargetObjects1.length !== 0 ? gdjs.Level1Code.GDCameraTargetObjects1[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level1Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level1Code.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Level1Code.GDPlayerObjects1[k] = gdjs.Level1Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level1Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDPlayerObjects1[i].setAnimationFrame(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21231292);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DebugText"), gdjs.Level1Code.GDDebugTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Musuh"), gdjs.Level1Code.GDMusuhObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDMusuhObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDMusuhObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Level1Code.GDDebugTextObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDDebugTextObjects1[i].getBehavior("Text").setText("BISAAA");
}
}
{ //Subevents
gdjs.Level1Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.Level1Code.eventsList3(runtimeScene);
}


{


gdjs.Level1Code.eventsList5(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level1Code.GDPortalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPortalObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Level1Code.GDTransitionObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level1Code.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.Level1Code.eventsList8(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Musuh"), gdjs.Level1Code.GDMusuhObjects1);
gdjs.copyArray(runtimeScene.getObjects("Musuh2"), gdjs.Level1Code.GDMusuh2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level1Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDMusuhObjects1ObjectsGDgdjs_9546Level1Code_9546GDMusuh2Objects1Objects, gdjs.Level1Code.mapOfGDgdjs_9546Level1Code_9546GDPlayerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDMusuhObjects1 */
/* Reuse gdjs.Level1Code.GDMusuh2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Level1Code.GDTransitionObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(3).setString((( gdjs.Level1Code.GDMusuh2Objects1.length === 0 ) ? (( gdjs.Level1Code.GDMusuhObjects1.length === 0 ) ? "" :gdjs.Level1Code.GDMusuhObjects1[0].getBehavior("Animation").getAnimationName()) :gdjs.Level1Code.GDMusuh2Objects1[0].getBehavior("Animation").getAnimationName()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber((( gdjs.Level1Code.GDMusuh2Objects1.length === 0 ) ? (( gdjs.Level1Code.GDMusuhObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDMusuhObjects1[0].getZOrder()) :gdjs.Level1Code.GDMusuh2Objects1[0].getZOrder()));
}{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Level1Code.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Battle");
}
{ //Subevents
gdjs.Level1Code.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsString() == "win");
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(false);
}
{ //Subevents
gdjs.Level1Code.eventsList11(runtimeScene);} //End of subevents
}

}


};

gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.GDDialogBoxdObjects1.length = 0;
gdjs.Level1Code.GDDialogBoxdObjects2.length = 0;
gdjs.Level1Code.GDDialogBoxdObjects3.length = 0;
gdjs.Level1Code.GDDialogBoxdObjects4.length = 0;
gdjs.Level1Code.GDNPCObjects1.length = 0;
gdjs.Level1Code.GDNPCObjects2.length = 0;
gdjs.Level1Code.GDNPCObjects3.length = 0;
gdjs.Level1Code.GDNPCObjects4.length = 0;
gdjs.Level1Code.GDTree1Objects1.length = 0;
gdjs.Level1Code.GDTree1Objects2.length = 0;
gdjs.Level1Code.GDTree1Objects3.length = 0;
gdjs.Level1Code.GDTree1Objects4.length = 0;
gdjs.Level1Code.GDTree2Objects1.length = 0;
gdjs.Level1Code.GDTree2Objects2.length = 0;
gdjs.Level1Code.GDTree2Objects3.length = 0;
gdjs.Level1Code.GDTree2Objects4.length = 0;
gdjs.Level1Code.GDBush1Objects1.length = 0;
gdjs.Level1Code.GDBush1Objects2.length = 0;
gdjs.Level1Code.GDBush1Objects3.length = 0;
gdjs.Level1Code.GDBush1Objects4.length = 0;
gdjs.Level1Code.GDHouse1Objects1.length = 0;
gdjs.Level1Code.GDHouse1Objects2.length = 0;
gdjs.Level1Code.GDHouse1Objects3.length = 0;
gdjs.Level1Code.GDHouse1Objects4.length = 0;
gdjs.Level1Code.GDHouse2Objects1.length = 0;
gdjs.Level1Code.GDHouse2Objects2.length = 0;
gdjs.Level1Code.GDHouse2Objects3.length = 0;
gdjs.Level1Code.GDHouse2Objects4.length = 0;
gdjs.Level1Code.GDEObjects1.length = 0;
gdjs.Level1Code.GDEObjects2.length = 0;
gdjs.Level1Code.GDEObjects3.length = 0;
gdjs.Level1Code.GDEObjects4.length = 0;
gdjs.Level1Code.GDE2Objects1.length = 0;
gdjs.Level1Code.GDE2Objects2.length = 0;
gdjs.Level1Code.GDE2Objects3.length = 0;
gdjs.Level1Code.GDE2Objects4.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects3.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects4.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects1.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects2.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects3.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects4.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects1.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects2.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects3.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects4.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects1.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects2.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects3.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects4.length = 0;
gdjs.Level1Code.GDCameraTargetObjects1.length = 0;
gdjs.Level1Code.GDCameraTargetObjects2.length = 0;
gdjs.Level1Code.GDCameraTargetObjects3.length = 0;
gdjs.Level1Code.GDCameraTargetObjects4.length = 0;
gdjs.Level1Code.GDPortalObjects1.length = 0;
gdjs.Level1Code.GDPortalObjects2.length = 0;
gdjs.Level1Code.GDPortalObjects3.length = 0;
gdjs.Level1Code.GDPortalObjects4.length = 0;
gdjs.Level1Code.GDPlayerObjects1.length = 0;
gdjs.Level1Code.GDPlayerObjects2.length = 0;
gdjs.Level1Code.GDPlayerObjects3.length = 0;
gdjs.Level1Code.GDPlayerObjects4.length = 0;
gdjs.Level1Code.GDMusuhObjects1.length = 0;
gdjs.Level1Code.GDMusuhObjects2.length = 0;
gdjs.Level1Code.GDMusuhObjects3.length = 0;
gdjs.Level1Code.GDMusuhObjects4.length = 0;
gdjs.Level1Code.GDNewSpriteObjects1.length = 0;
gdjs.Level1Code.GDNewSpriteObjects2.length = 0;
gdjs.Level1Code.GDNewSpriteObjects3.length = 0;
gdjs.Level1Code.GDNewSpriteObjects4.length = 0;
gdjs.Level1Code.GDDebugTextObjects1.length = 0;
gdjs.Level1Code.GDDebugTextObjects2.length = 0;
gdjs.Level1Code.GDDebugTextObjects3.length = 0;
gdjs.Level1Code.GDDebugTextObjects4.length = 0;
gdjs.Level1Code.GDtpObjects1.length = 0;
gdjs.Level1Code.GDtpObjects2.length = 0;
gdjs.Level1Code.GDtpObjects3.length = 0;
gdjs.Level1Code.GDtpObjects4.length = 0;
gdjs.Level1Code.GDDebugText2Objects1.length = 0;
gdjs.Level1Code.GDDebugText2Objects2.length = 0;
gdjs.Level1Code.GDDebugText2Objects3.length = 0;
gdjs.Level1Code.GDDebugText2Objects4.length = 0;
gdjs.Level1Code.GDMusuh2Objects1.length = 0;
gdjs.Level1Code.GDMusuh2Objects2.length = 0;
gdjs.Level1Code.GDMusuh2Objects3.length = 0;
gdjs.Level1Code.GDMusuh2Objects4.length = 0;
gdjs.Level1Code.GDTransitionObjects1.length = 0;
gdjs.Level1Code.GDTransitionObjects2.length = 0;
gdjs.Level1Code.GDTransitionObjects3.length = 0;
gdjs.Level1Code.GDTransitionObjects4.length = 0;

gdjs.Level1Code.eventsList12(runtimeScene);
gdjs.Level1Code.GDDialogBoxdObjects1.length = 0;
gdjs.Level1Code.GDDialogBoxdObjects2.length = 0;
gdjs.Level1Code.GDDialogBoxdObjects3.length = 0;
gdjs.Level1Code.GDDialogBoxdObjects4.length = 0;
gdjs.Level1Code.GDNPCObjects1.length = 0;
gdjs.Level1Code.GDNPCObjects2.length = 0;
gdjs.Level1Code.GDNPCObjects3.length = 0;
gdjs.Level1Code.GDNPCObjects4.length = 0;
gdjs.Level1Code.GDTree1Objects1.length = 0;
gdjs.Level1Code.GDTree1Objects2.length = 0;
gdjs.Level1Code.GDTree1Objects3.length = 0;
gdjs.Level1Code.GDTree1Objects4.length = 0;
gdjs.Level1Code.GDTree2Objects1.length = 0;
gdjs.Level1Code.GDTree2Objects2.length = 0;
gdjs.Level1Code.GDTree2Objects3.length = 0;
gdjs.Level1Code.GDTree2Objects4.length = 0;
gdjs.Level1Code.GDBush1Objects1.length = 0;
gdjs.Level1Code.GDBush1Objects2.length = 0;
gdjs.Level1Code.GDBush1Objects3.length = 0;
gdjs.Level1Code.GDBush1Objects4.length = 0;
gdjs.Level1Code.GDHouse1Objects1.length = 0;
gdjs.Level1Code.GDHouse1Objects2.length = 0;
gdjs.Level1Code.GDHouse1Objects3.length = 0;
gdjs.Level1Code.GDHouse1Objects4.length = 0;
gdjs.Level1Code.GDHouse2Objects1.length = 0;
gdjs.Level1Code.GDHouse2Objects2.length = 0;
gdjs.Level1Code.GDHouse2Objects3.length = 0;
gdjs.Level1Code.GDHouse2Objects4.length = 0;
gdjs.Level1Code.GDEObjects1.length = 0;
gdjs.Level1Code.GDEObjects2.length = 0;
gdjs.Level1Code.GDEObjects3.length = 0;
gdjs.Level1Code.GDEObjects4.length = 0;
gdjs.Level1Code.GDE2Objects1.length = 0;
gdjs.Level1Code.GDE2Objects2.length = 0;
gdjs.Level1Code.GDE2Objects3.length = 0;
gdjs.Level1Code.GDE2Objects4.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects3.length = 0;
gdjs.Level1Code.GDShadedDarkJoystickObjects4.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects1.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects2.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects3.length = 0;
gdjs.Level1Code.GDTargetRoundButtonObjects4.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects1.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects2.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects3.length = 0;
gdjs.Level1Code.GDTilemap_9595GroundObjects4.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects1.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects2.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects3.length = 0;
gdjs.Level1Code.GDTilemap_9595WaterObjects4.length = 0;
gdjs.Level1Code.GDCameraTargetObjects1.length = 0;
gdjs.Level1Code.GDCameraTargetObjects2.length = 0;
gdjs.Level1Code.GDCameraTargetObjects3.length = 0;
gdjs.Level1Code.GDCameraTargetObjects4.length = 0;
gdjs.Level1Code.GDPortalObjects1.length = 0;
gdjs.Level1Code.GDPortalObjects2.length = 0;
gdjs.Level1Code.GDPortalObjects3.length = 0;
gdjs.Level1Code.GDPortalObjects4.length = 0;
gdjs.Level1Code.GDPlayerObjects1.length = 0;
gdjs.Level1Code.GDPlayerObjects2.length = 0;
gdjs.Level1Code.GDPlayerObjects3.length = 0;
gdjs.Level1Code.GDPlayerObjects4.length = 0;
gdjs.Level1Code.GDMusuhObjects1.length = 0;
gdjs.Level1Code.GDMusuhObjects2.length = 0;
gdjs.Level1Code.GDMusuhObjects3.length = 0;
gdjs.Level1Code.GDMusuhObjects4.length = 0;
gdjs.Level1Code.GDNewSpriteObjects1.length = 0;
gdjs.Level1Code.GDNewSpriteObjects2.length = 0;
gdjs.Level1Code.GDNewSpriteObjects3.length = 0;
gdjs.Level1Code.GDNewSpriteObjects4.length = 0;
gdjs.Level1Code.GDDebugTextObjects1.length = 0;
gdjs.Level1Code.GDDebugTextObjects2.length = 0;
gdjs.Level1Code.GDDebugTextObjects3.length = 0;
gdjs.Level1Code.GDDebugTextObjects4.length = 0;
gdjs.Level1Code.GDtpObjects1.length = 0;
gdjs.Level1Code.GDtpObjects2.length = 0;
gdjs.Level1Code.GDtpObjects3.length = 0;
gdjs.Level1Code.GDtpObjects4.length = 0;
gdjs.Level1Code.GDDebugText2Objects1.length = 0;
gdjs.Level1Code.GDDebugText2Objects2.length = 0;
gdjs.Level1Code.GDDebugText2Objects3.length = 0;
gdjs.Level1Code.GDDebugText2Objects4.length = 0;
gdjs.Level1Code.GDMusuh2Objects1.length = 0;
gdjs.Level1Code.GDMusuh2Objects2.length = 0;
gdjs.Level1Code.GDMusuh2Objects3.length = 0;
gdjs.Level1Code.GDMusuh2Objects4.length = 0;
gdjs.Level1Code.GDTransitionObjects1.length = 0;
gdjs.Level1Code.GDTransitionObjects2.length = 0;
gdjs.Level1Code.GDTransitionObjects3.length = 0;
gdjs.Level1Code.GDTransitionObjects4.length = 0;


return;

}

gdjs['Level1Code'] = gdjs.Level1Code;
